<?php
return [
    'zoom_level'           => 13,
    'detail_zoom_level'    => 20,
    'map_center_latitude'  => env('MAP_CENTER_LATITUDE', '-6.537537'),
    'map_center_longitude' => env('MAP_CENTER_LONGITUDE', '108.352791'),
    // UNTUK MENGAMBIL LATITUDE DAN LONGITUDE SILAHKAN LAKUKAN SECARA MANUAL ATAU AKSES HALAMAN CREATE KEMUDIAN
    // GESER KE LOKASI YANG DI INGINKAN
];
