<link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.5.6/css/buttons.dataTables.min.css">
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-12">
            <div class="card">
                 <?php if (isset($component)) { $__componentOriginalf6d1e1ab7a8df2de5d0bdc28df8775f180a35b0c = $component; } ?>
<?php $component = $__env->getContainer()->make(Mckenziearts\Notify\NotifyComponent::class, []); ?>
<?php $component->withName('notify-messages'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf6d1e1ab7a8df2de5d0bdc28df8775f180a35b0c)): ?>
<?php $component = $__componentOriginalf6d1e1ab7a8df2de5d0bdc28df8775f180a35b0c; ?>
<?php unset($__componentOriginalf6d1e1ab7a8df2de5d0bdc28df8775f180a35b0c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                <div class="card-header">Pengajuan Kegiatan</div>
                <div class="card-body">
                    <div class="form-group col-md-4">
                        <label>Seller</label>            
                       <select class="form-control select2" id="seller2" style="width: 200px" data-style="btn btn-outline-primary">
                         <option value="">--Semua--</option>
                        <?php $__currentLoopData = $anggotas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
            
            
            
            <option value="<?php echo e($seller->anggota_id); ?>"><?php echo e($seller->nama); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           
                        </select>
                        </div>
                    
                        
                        
                        
                            
                            
                            
                            
                    <a href="<?php echo e(route('places.create')); ?>" class="btn btn-primary btn-sm float-right">Tambah</a>
                    
                        
                    <table class="table table-hovered" id="tablePlace">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Kegiatan</th>
                                <th>Nama Anggota</th>
                                <th>Tanggal Kegiatan</th>
                                <th>Status Kegiatan</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                    
                </div>
            </div>
        </div>
    </div>
</div>

<form action="" method="post" id="deleteForm">
    <?php echo csrf_field(); ?>
    <?php echo method_field("DELETE"); ?>
    <input type="submit" value="Hapus" style="display:none">
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('DataTables'); ?>
<link rel="stylesheet" href="<?php echo e(asset('/vendor/datatables/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/vendor/datatables/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/vendor/datatables/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/datatables/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/datatables/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/datatables/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
<script src="https://cdn.datatables.net/buttons/1.5.6/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.flash.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.print.min.js"></script>
    <script>
        // $(function(){
        //     $('#tablePlace').DataTable({
        //         processing:true,
        //         serverSide:true,
        //         ajax: '<?php echo e(route('place.data')); ?>',
        //         columns:[
        //             {data: 'DT_RowIndex',orderable:false,searchable:false},
        //             {data: 'place_name'},
        //             {data: 'tanggal_kegiatan'},
        //             {data: 'nama'},
        //             {data: 'action'}
        //         ]
        //     })
        // });

        $(document).ready(function(){
        load_data();
    })
    $('#seller2').change(function(){
    var seller = $(this).val()
    if(seller !== ""){
     load_data();
    }
     
    })
    function load_data(){
        $('#tablePlace').DataTable().destroy();
        
        $('#tablePlace').DataTable( {
            
         "processing": true,
        "serverSide": true,
        "ajax": {
            "url": "<?php echo e(url('/place/datatable')); ?>",
            "type": "POST",
            
            "data":{'_token':$("input[name='_token']").val(),'seller':$('#seller2 :selected').val()}
        },
        "columns":[ { "data": null,"sortable": false, 
       render: function (data, type, row, meta) {
                 return meta.row + meta.settings._iDisplayStart + 1;
                }  
    },
                 {data: 'place_name'},
                 {data: 'nama'},
                 {data: 'tanggal_kegiatan'},
                 {data: 'status_kegiatan'},
                 
                 { data: null, render: function ( data, type, row ) {
    let urledit = "<?php echo e(URL::to('/')); ?>/keg/edit/"+data['id'];
    let urldetail = "<?php echo e(URL::to('/')); ?>/keg/detail/"+data['id'];
    let urlconf = "<?php echo e(URL::to('/')); ?>/keg/conf/"+data['id'];
    return '<a href="'+urldetail+'" class="btn btn-info"/>Detail</a> '
    +'<a href="'+urledit+'" class="btn btn-primary"/>Edit</a> '
    +'<a href="'+urlconf+'" class="btn btn-success"/>Konfirmasi</a> '
    +"<a href='javascript:void(0)' onclick='delete_id("+data['id']+")' class='btn btn-danger'>Delete</a>";    
           } },  
            ],
            "oLanguage": {
                
         "oPaginate": { "sPrevious": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-left"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>', "sNext": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>' },
                "sInfo": "Showing page PAGE of PAGES",
                "sSearch": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>',
                "sSearchPlaceholder": "Search...",
               "sLengthMenu": "Results :  MENU",
            },
            "stripeClasses": [],
            "lengthMenu": [5, 10, 20, 50,100,500],
            "pageLength": 5 
            
            
        });
    }
    function delete_id(id){
    var ask = ("Are Sure?");
    if(ask){
    
  
     $.ajax({
                url:"<?php echo e(url('keg/hapus')); ?>/"+id,
                method: 'GET',
                cache: false,
                contentType: false,
                processData: false,
                success: function(response) {
                    alert("Hapus Data berhasil");
                    load_data();
                },error: function (error) {
                     alert("Hapus Data Gagal");          
                }
           });
    }
}

    function cetak(){
        window.print();
    }
    $('a.printPage').click(function(){
    
    
     newWin= window.open();
             var divToPrint = document.getElementById('printarea');
             newWin.document.write(divToPrint.innerHTML);
             newWin.document.close();
             newWin.focus();
             newWin.print();
           
            return false;
 });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('tamplate.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\web-siskegbin\resources\views/admin/places/index.blade.php ENDPATH**/ ?>