<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-12">
            <div class="card">
                 <?php if (isset($component)) { $__componentOriginalf6d1e1ab7a8df2de5d0bdc28df8775f180a35b0c = $component; } ?>
<?php $component = $__env->getContainer()->make(Mckenziearts\Notify\NotifyComponent::class, []); ?>
<?php $component->withName('notify-messages'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf6d1e1ab7a8df2de5d0bdc28df8775f180a35b0c)): ?>
<?php $component = $__componentOriginalf6d1e1ab7a8df2de5d0bdc28df8775f180a35b0c; ?>
<?php unset($__componentOriginalf6d1e1ab7a8df2de5d0bdc28df8775f180a35b0c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                <div class="card-header">Data Anggota</div>
                <div class="card-body">
                    <a href="<?php echo e(route('anggotas.create')); ?>" class="btn btn-primary btn-sm float-right">Tambah</a>
                    <a href="<?php echo e(route('show_import')); ?>" class="btn btn-primary btn-sm float-right">Import</a>
                    <table class="table table-hovered" id="tablePlace">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Name</th>
                                <th>Pangkat</th>
                                <th>NRP</th>
                                <th>Jabatan</th>
                                <th>Desa</th>
                                <th>Foto</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                 $no =1;
                            ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $anggota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td><?php echo e($no++); ?> </td>
                                <td hidden><?php echo e($anggota->anggota_id); ?></td>

                                <td><?php echo e($anggota->nama); ?></td>
                                <td><?php echo e($anggota->pangkat); ?></td>
                                <td><?php echo e($anggota->nrp); ?></td>
                                <td><?php echo e($anggota->jabatan); ?></td>
                                <td><?php echo e($anggota->desa); ?></td>
                                
                                <td><img src=" <?php echo e(asset('uploads/' . $anggota->foto)); ?> " width="150"></td>


                                <td>
                                    <form action="<?php echo e(route('anggotas.destroy',$anggota->anggota_id)); ?>" method="POST">

                                        <a class="btn btn-info" href="<?php echo e(route('anggotas.show',$anggota->anggota_id)); ?>">Detail</a>

                                        <a class="btn btn-primary" href="<?php echo e(route('anggotas.edit',$anggota->anggota_id)); ?>">Ubah</a>

                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>

                                        <button type="submit" class="btn btn-danger">Hapus</button>
                                    </form>
                                </td>


                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<form action="" method="post" id="deleteForm">
    <?php echo csrf_field(); ?>
    <?php echo method_field("DELETE"); ?>
    <input type="submit" value="Hapus" style="display:none">
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tamplate.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\web-siskegbin\resources\views/admin/anggotas/index.blade.php ENDPATH**/ ?>