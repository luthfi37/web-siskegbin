

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-12">
            <div class="card">
                 <?php if (isset($component)) { $__componentOriginalf6d1e1ab7a8df2de5d0bdc28df8775f180a35b0c = $component; } ?>
<?php $component = $__env->getContainer()->make(Mckenziearts\Notify\NotifyComponent::class, []); ?>
<?php $component->withName('notify-messages'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalf6d1e1ab7a8df2de5d0bdc28df8775f180a35b0c)): ?>
<?php $component = $__componentOriginalf6d1e1ab7a8df2de5d0bdc28df8775f180a35b0c; ?>
<?php unset($__componentOriginalf6d1e1ab7a8df2de5d0bdc28df8775f180a35b0c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                <div class="card-header">Add New Place</div>
                <div class="card-body">
                    <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-primary btn-sm float-right">Add New Role</a>
                    <table class="table table-hovered" id="tablePlace">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Role Name</th>
                                <th>Option</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <tr>
                                
                                <td><?php echo e($role->role_id); ?></td>
                                <td><?php echo e($role->role_name); ?></td>
                                
                                <td>
                                    <form action="<?php echo e(route('roles.destroy',$role->role_id)); ?>" method="POST">
                       
                                        <a class="btn btn-info" href="<?php echo e(route('roles.show',$role->role_id)); ?>">Show</a>
                        
                                        <a class="btn btn-primary" href="<?php echo e(route('roles.edit',$role->role_id)); ?>">Edit</a>
                       
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                          
                                        <button type="submit" class="btn btn-danger">Delete</button>
                                    </form>
                                </td>
                    
                                
                            </tr>   
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<form action="" method="post" id="deleteForm">
    <?php echo csrf_field(); ?>
    <?php echo method_field("DELETE"); ?>
    <input type="submit" value="Hapus" style="display:none">
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('DataTables'); ?>
<link rel="stylesheet" href="<?php echo e(asset('/vendor/datatables/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('/vendor/datatables/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/vendor/datatables/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/datatables/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/datatables/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('/vendor/datatables/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\laravel-gis\resources\views/role/index.blade.php ENDPATH**/ ?>