<footer>
    <div class="pull-right">
      Pendataan dan Pelaporan Kegiatan BABINSA by<a href="https://colorlib.com">KORAMIL 1606/KERTASEMAYA</a>
    </div>
    <div class="clearfix"></div>
  </footer>
<?php /**PATH E:\laravel\web-siskegbin\resources\views/include/footer.blade.php ENDPATH**/ ?>