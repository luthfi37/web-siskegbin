
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">Detail Place</div>
                <div class="card-body">
                    
                    <table class="table">
                        <tbody>
                            <tr><td>Nama Kegiatan</td><td><?php echo e($place->place_name); ?></td></tr>
                            <tr><td>Tanggal Kegiatan</td><td><?php echo e($place->tanggal_kegiatan); ?></td></tr>
                            <tr><td>Alamat</td><td><?php echo e($place->address); ?></td></tr>
                            <tr><td>Deskripsi</td><td><?php echo e($place->description); ?></td></tr>
                            <td><img src=" <?php echo e(asset('uploads/' . $place->image)); ?> " width="500"></td>
                            
                            <tr><td>Nama</td><td><select name="anggota_id" class="form-control" disabled>
                                <?php $__currentLoopData = $anggotas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($row->anggota_id); ?>"><?php echo e($row->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select></td></tr>
                            <form action="" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                            <tr>
                                <input type="hidden" name="place_id" id="place_id" class="form-control" value="<?php echo e($place->id); ?>">
                                <td>Konfirmasi Titik</td><td><select name="conf" id="conf" class="form-control" >
                                
                                    <option value="sama">sama</option>
                                    <option value="tidak sama">tidak sama</option>
                                
                            </select></td>
                        </tr>
                            
                        </tbody>
                        <td><a href="<?php echo e(route('places.index')); ?>" class="btn btn-secondary">Kembali</a> || 
                            <a href="javascript:void" class="btn btn-primary" id="saveButton">Konfirmasi</a>
                        </td>
                        
                    </form>
                    </table>
                    
                </div>
            </div>
            <div class="card">
                <div class="card-header">Detail Place Conf</div>
                <div id="mapconf"></div>
                
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">Detail Place</div>
                <div class="card-body" id="mapid"></div>
                
            </div>
        </div>
       
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
<!-- Leaflet CSS -->
      <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css"
      integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A=="
      crossorigin=""/>
    <style>
      #mapid { min-height: 500px; }
      #mapconf { min-height: 500px; }
    </style>
<?php $__env->stopSection(); ?>



<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    $("#saveButton").click(function(){
        formData = {
            'id':$("#place_id").val(),
            'conf':$("#conf").val(),
            

            '_token':$("input[name='_token']").val()
        }


         $.ajax({
                    url:"<?php echo e(url('/places/conf')); ?>",
                    method: 'POST',
                    data: formData,
                    cache: false,
                    success: function(response) {
                       response = JSON.parse(response);
                       if(response.success == true){
                        alert('Data Berhasil Konfirmasi');
                        window.location = "/places"
                       }else{
                        alert("Gagal Menyimpan Data");
                       }
                    },error: function (error) {
                         alert("Terjadi Kesalahan");
                    }
               });
    });
        </script>
<!-- Leaflet JavaScript -->
      <!-- Make sure you put this AFTER Leaflet's CSS -->
      <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"
          integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA=="
          crossorigin="">
      </script>

<script>
   var map = L.map('mapid').setView([<?php echo e($place->latitude); ?>,<?php echo e($place->longitude); ?>],<?php echo e(config('leafletsetup.detail_zoom_level')); ?>);
    
   L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    L.marker([<?php echo e($place->latitude); ?>,<?php echo e($place->longitude); ?>]).addTo(map)

    axios.get('<?php echo e(route('api.places.index')); ?>')
    .then(function (response) {
        //console.log(response.data);
        L.geoJSON(response.data,{
            pointToLayer: function(geoJsonPoint,latlng) {
                return L.marker(latlng);
            }
        })
        .bindPopup(function(layer) {
            //return layer.feature.properties.map_popup_content;
            return ('<div class="my-2"><strong>Place Name</strong> :<br>'+layer.feature.properties.place_name+'</div> <div class="my-2"><strong>Description</strong>:<br>'+layer.feature.properties.description+'</div><div class="my-2"><strong>Address</strong>:<br>'+layer.feature.properties.address+'</div>');
        }).addTo(map);
        console.log(response.data);
    })
    .catch(function (error) {
        console.log(error);
    });

//map confir

var map = L.map('mapconf').setView([<?php echo e($place->latitude_conf); ?>,<?php echo e($place->longitude_conf); ?>],<?php echo e(config('leafletsetup.detail_zoom_level')); ?>);
    
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
         attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
     }).addTo(map);
 
     L.marker([<?php echo e($place->latitude_conf); ?>,<?php echo e($place->longitude_conf); ?>]).addTo(map)
 
     axios.get('<?php echo e(route('api.places.index')); ?>')
     .then(function (response) {
         //console.log(response.data);
         L.geoJSON(response.data,{
             pointToLayer: function(geoJsonPoint,latlng) {
                 return L.marker(latlng);
             }
         })
         .bindPopup(function(layer) {
             //return layer.feature.properties.map_popup_content;
             return ('<div class="my-2"><strong>Place Name</strong> :<br>'+layer.feature.properties.place_name+'</div> <div class="my-2"><strong>Description</strong>:<br>'+layer.feature.properties.description+'</div><div class="my-2"><strong>Address</strong>:<br>'+layer.feature.properties.address+'</div>');
         }).addTo(map);
         console.log(response.data);
     })
     .catch(function (error) {
         console.log(error);
     });
   
</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\web-siskegbin\resources\views/admin/places/confplace.blade.php ENDPATH**/ ?>