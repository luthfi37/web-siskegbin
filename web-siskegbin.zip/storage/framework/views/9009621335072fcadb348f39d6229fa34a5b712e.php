<!-- Bootstrap -->
<link href="<?php echo e(asset('tamplate/vendors/bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet">
<!-- Font Awesome -->
<link href="<?php echo e(asset('tamplate/vendors/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
<!-- NProgress -->
<link href="<?php echo e(asset('tamplate/vendors/nprogress/nprogress.css')); ?>" rel="stylesheet">
<!-- iCheck -->
<link href="<?php echo e(asset('tamplate/vendors/iCheck/skins/flat/green.css')); ?>" rel="stylesheet">

<!-- bootstrap-progressbar -->
<link href="<?php echo e(asset('tamplate/vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css')); ?>" rel="stylesheet">
<!-- JQVMap -->
<link href="<?php echo e(asset('tamplate/vendors/jqvmap/dist/jqvmap.min.css')); ?>" rel="stylesheet"/>
<!-- bootstrap-daterangepicker -->
<link href="<?php echo e(asset('tamplate/vendors/bootstrap-daterangepicker/daterangepicker.css')); ?>" rel="stylesheet">

<!-- Custom Theme Style -->
<link href="<?php echo e(asset('tamplate/build/css/custom.min.css')); ?>" rel="stylesheet">


<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css"
        integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
<?php /**PATH E:\Xampp\htdocs\web-siskegbin\resources\views/include/style.blade.php ENDPATH**/ ?>