<div class="top_nav">
    <div class="nav_menu">
        <div class="nav toggle">
          <a id="menu_toggle"><i class="fa fa-bars"></i></a>
        </div>
        <nav class="nav navbar-nav">
        <ul class=" navbar-right">
                </div>
              </li>
            </ul>
          </li>
        </ul>
      </nav>
    </div>
  </div>
<?php /**PATH E:\laravel\web-siskegbin\resources\views/include/navbar.blade.php ENDPATH**/ ?>