<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
    <div class="menu_section">
      <h3>Menu Utama</h3>
      <ul class="nav side-menu">
        <li><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-home"></i> Dashboard <span class=""></span></a>
        </li>
        <li><a href="<?php echo e(route('roles.index')); ?>"><i class="fa fa-desktop"></i> Manajemen Role <span class=""></span></a>
        </li>
        <li><a href="<?php echo e(route('admins.index')); ?>"><i class="fa fa-address-book"></i> Data Pengguna <span class=""></span></a>
        </li>
        <li><a href="<?php echo e(route('anggotas.index')); ?>"><i class="fa fa-user"></i> Data Anggota <span class=""></span></a>
        </li>
        <li><a href="<?php echo e(route('places.index')); ?>"><i class="fa fa-edit"></i> Pengajuan Kegiatan <span class=""></span></a>
        </li>
        <li><a href="<?php echo e(url('/printkeg')); ?>"><i class="fa fa-address-book"></i> Laporan <span class=""></span></a>
        </li>
        <li class="<?php echo e(Request::is('logout*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                document.getElementById('logout-form').submit();">
                <i class="fa fa-sign-out"></i>
					<span class="link-collapse">Keluar</span>
						<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
						<?php echo csrf_field(); ?>
						</form></a>
			</a>
        </li>
        </li>
        
            
        </li>
      </ul>
    </div>

  </div>
  <!-- /sidebar menu -->
<?php /**PATH E:\Xampp\htdocs\web-siskegbin\resources\views/include/sidebar.blade.php ENDPATH**/ ?>